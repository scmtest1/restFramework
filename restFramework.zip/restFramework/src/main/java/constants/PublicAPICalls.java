package constants;

public class PublicAPICalls {
    
    //v3 Token Management API
    public static final String CREATE_TOKEN = "/api/public/v3/access-tokens";
    public static final String GET_TOKEN = "/api/public/v3/access-tokens";
    public static final String DELETE_TOKEN = "/api/public/v3/access-tokens/TOKENID";

}
